def saySomethingUpercase(text):
    return text.upper()

def saySomethingLowercase(text):
    return text.lower()
